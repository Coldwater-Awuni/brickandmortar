import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:brickandmortar/providers/cart_provider.dart';
import 'package:brickandmortar/widgets/newNavbar.dart';


import '../utils/responsive.dart';
import '../widgets/cartpage/cart_sidebar.dart';

// class CartPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: PreferredSize(
//         preferredSize: Size.fromHeight(60.0),
//         child: Navbarnew(),
//       ),
//       body: ResponsiveWidget(
//         largeScreen: Row(
//           children: [
//             Expanded(
//               flex: 3,
//               child: _buildCartContent(context),
//             ),
//             Expanded(
//               flex: 1,
//               child: CartSidebar(),
//             ),
//           ],
//         ),
//         mediumScreen: Row(
//           children: [
//             Expanded(
//               flex: 3,
//               child: _buildCartContent(context),
//             ),
//             Expanded(
//               flex: 1,
//               child: CartSidebar(),
//             ),
//           ],
//         ),
//         smallScreen: _buildCartContent(context),
//       ),
//     );
//   }

//   Widget _buildCartContent(BuildContext context) {
//     return Consumer<CartProvider>(
//       builder: (context, cartProvider, child) {
//         return Column(
//           children: [
//             Padding(
//               padding: const EdgeInsets.all(16.0),
//               child: Text(
//                 'Cart Items',
//                 style: TextStyle(
//                   fontSize: 20,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//             Expanded(
//               child: ListView.builder(
//                 itemCount: cartProvider.cart.items.length,
//                 itemBuilder: (context, index) {
//                   final cartItem = cartProvider.cart.items[index];
//                   return ListTile(
//                     leading: Image.asset(cartItem.product.primaryImage),
//                     title: Text(cartItem.product.name),
//                     subtitle: Text('\$${cartItem.product.price}'),
//                     trailing: Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         IconButton(
//                           icon: Icon(Icons.remove),
//                           onPressed: () {
//                             cartProvider.updateQuantity(
//                               cartItem.product,
//                               cartItem.quantity - 1,
//                             );
//                           },
//                         ),
//                         Text('${cartItem.quantity}'),
//                         IconButton(
//                           icon: Icon(Icons.add),
//                           onPressed: () {
//                             cartProvider.updateQuantity(
//                               cartItem.product,
//                               cartItem.quantity + 1,
//                             );
//                           },
//                         ),
//                       ],
//                     ),
//                   );
//                 },
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.all(16.0),
//               child: ElevatedButton(
//                 onPressed: () {
//                   // Implement checkout functionality
//                 },
//                 child: Text('Checkout'),
//                 style: ElevatedButton.styleFrom(
//                   minimumSize: Size(double.infinity, 50),
//                 ),
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }
// }


class CartPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
           context.goNamed("Home");
          },
        ),
        title: Text('Cart'),
      ),
      body: ResponsiveWidget(
        largeScreen: Row(
          children: [
            Expanded(
              flex: 3,
              child: _buildCartContent(context),
            ),
            Expanded(
              flex: 1,
              child: CartSidebar(),
            ),
          ],
        ),
        mediumScreen: Row(
          children: [
            Expanded(
              flex: 3,
              child: _buildCartContent(context),
            ),
            Expanded(
              flex: 1,
              child: CartSidebar(),
            ),
          ],
        ),
        smallScreen: _buildCartContent(context),
      ),
    );
  }

  Widget _buildCartContent(BuildContext context) {
    return Consumer<CartProvider>(
      builder: (context, cartProvider, child) {
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Cart Items',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: cartProvider.cart.items.length,
                itemBuilder: (context, index) {
                  final cartItem = cartProvider.cart.items[index];
                  return ListTile(
                    leading: Image.asset(cartItem.product.primaryImage),
                    title: Text(cartItem.product.name),
                    subtitle: Text('\$${cartItem.product.price}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.remove),
                          onPressed: () {
                            cartProvider.updateQuantity(
                              cartItem.product,
                              cartItem.quantity - 1,
                            );
                          },
                        ),
                        Text('${cartItem.quantity}'),
                        IconButton(
                          icon: Icon(Icons.add),
                          onPressed: () {
                            cartProvider.updateQuantity(
                              cartItem.product,
                              cartItem.quantity + 1,
                            );
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: () {
                  // Implement checkout functionality
                },
                child: Text('Checkout'),
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
