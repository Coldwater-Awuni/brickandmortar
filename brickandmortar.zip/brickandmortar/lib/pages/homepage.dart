import 'package:brickandmortar/constants/grid_data.dart';
import 'package:brickandmortar/pages/homepage/grid_sections.dart';
import 'package:brickandmortar/pages/homepage/social_media_embed/social_embed.dart';
import 'package:brickandmortar/widgets/cartpage/cart_sidebar.dart';
import 'package:brickandmortar/widgets/navigationbar.dart';
import 'package:brickandmortar/widgets/newNavbar.dart';
import 'package:brickandmortar/widgets/sideNivigationBar.dart';
import 'package:flutter/material.dart';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:brickandmortar/widgets/footer.dart';
import 'package:brickandmortar/utils/responsive.dart';
import 'package:go_router/go_router.dart';
import '../pages/products/productsPage.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../routes/routes.dart';

import './homepage/subcriptions.dart';
import 'homepage/first_section.dart';
class HomeScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _scrollController = ScrollController();
  double _scrollPosition = 0;

  @override
  void initState() {
    _scrollController.addListener(_scrollListener);
    super.initState();
  }

  _scrollListener() {
    setState(() {
      _scrollPosition = _scrollController.position.pixels;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: NavDrawer(),
      endDrawer: CartSidebar(),
      body: SingleChildScrollView(
        child: Column(
            children: [
              Navbarnew(),
               const SizedBox(height: 10,),
              _buildUI()
            ],
          ),
      ),
    );
  }
TextStyle _responsiveTextStyle(BuildContext context, double small, double medium, double large) {
  double width = MediaQuery.of(context).size.width;
  if (width > 1200) {
    return TextStyle(fontSize: large);
  } else if (width >= 800) {
    return TextStyle(fontSize: medium);
  } else {
    return TextStyle(fontSize: small);
  }
}

EdgeInsets _responsivePadding(BuildContext context, double small, double medium, double large) {
  double width = MediaQuery.of(context).size.width;
  if (width > 1200) {
    return EdgeInsets.symmetric(vertical: large, horizontal: large * 2);
  } else if (width >= 800) {
    return EdgeInsets.symmetric(vertical: medium, horizontal: medium * 2);
  } else {
    return EdgeInsets.symmetric(vertical: small, horizontal: small * 2);
  }
}


  Widget _buildUI() {
     double spacing = MediaQuery.of(context).size.height ; // 5% of the view height
    return SingleChildScrollView(
      controller: _scrollController,
      
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [         
          const ResponsiveWidget(
            // Use ResponsiveWidget to display different images for different screen sizes
            largeScreen: FirstSection(imagePath:'assets/img/firstpage/largerscreen.jpg'),
            mediumScreen: FirstSection(imagePath: 'assets/img/firstpage/meduimscreen.jpg'),
            smallScreen: FirstSection(imagePath: 'assets/img/firstpage/smallscreen.jpg'),
          ),
          // Section title
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 20.0),
            child: Text(
              'Shop by Products',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          // Grid section
          grid_sections(bundle: products,),
          
          SizedBox(height:spacing*0.05,),
          // New section with a slider
          const SubscriptionSection(),
        // Spacing between sections
          SizedBox(height: spacing * 0.05),
            // New hero section
           _heroSection(),
          SizedBox(height:spacing* 0.07,),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 20.0),
            child: Text(
              'Shop by Rooms',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          grid_sections(bundle: bundles,),           
           SizedBox(height:spacing* 0.05,),
          
          _fullScreenSliderSection(),
           SizedBox(height:spacing*0.05,),

          //  const SocialMediaEmbedContainer(
          //   embedUrl: '<iframe width="560" height="315" src="https://www.youtube.com/embed/nsnQJrYHHNQ?si=6q8bBCYNnpC2rnlR" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>',
          //     )
          //  footerSection(context), // Footer section
           
        ],
      ),
    );
  }





  // New section with a full-width slider using carousel_slider
  Widget _fullScreenSliderSection() {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.7, // Cover 65% of the view height
      width: double.infinity, // Full width
      child: Stack(
        children: [
          CarouselSlider(
            options: CarouselOptions(
              height: MediaQuery.of(context).size.height * 0.7,
              autoPlay: true,
              autoPlayInterval: Duration(seconds: 20), // Reduced speed
              enlargeCenterPage: true,
              viewportFraction: 1.0, // Full-screen display
              aspectRatio: MediaQuery.of(context).size.aspectRatio,
              pageSnapping: true,
              disableCenter: true,
              scrollPhysics: ClampingScrollPhysics(),
              autoPlayAnimationDuration: Duration(milliseconds: 5000), // Adjust animation duration
              autoPlayCurve: Curves.easeInOut, // Fade in/out transition
            ),
            items: [
              _buildSliderItem('assets/img/slider/slide1.jpg'),
              _buildSliderItem('assets/img/slider/slide2.jpg'),
              _buildSliderItem('assets/img/slider/slide3.jpg'),
            ],
          ),
          // Overlay text and button
          Positioned(
            top: 20, // Position at the center top
            left: 0,
            right: 0,
            child: Center(
              child: Column(
                children: [
                   Text(
                    'Discover Our Collections',
                    style: _responsiveTextStyle(context, 18, 24, 32),
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () {
                      // Handle button press
                    },
                    style: ElevatedButton.styleFrom(
                       padding: _responsivePadding(context, 12, 16, 24), // Responsive padding
                  ),
                    child: const Text(
                      'Shop Now',
                      style: TextStyle(
                        fontSize: 32,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Build individual slider item
  Widget _buildSliderItem(String imagePath) {
    return Image.asset(
      imagePath,
      fit: BoxFit.cover,
      width: double.infinity,
    );
  }

Widget _heroSection() {
  return Container(
    height: MediaQuery.of(context).size.height * 0.65, // Cover 65% of the view height
    width: double.infinity, // Full width
    decoration: const BoxDecoration(
      image: DecorationImage(
        image: AssetImage('assets/img/hero1.jpg'),
        fit: BoxFit.cover,
      ),
    ),
    child: Stack(
      children: [
        Positioned(
          top: 20, // Position at the center top
          left: 0,
          right: 0,
          child: Center(
            child: Column(
              children: [
                Text(
                  'Shop By Rooms',
                  style: _responsiveTextStyle(context, 18, 24, 32), // Responsive text style
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () {
                    // Handle button press
                  },
                  style: ElevatedButton.styleFrom(
                    padding: _responsivePadding(context, 12, 16, 24), // Responsive padding
                  ),
                  child: Text(
                    'Shop by Rooms',
                    style: _responsiveTextStyle(context, 24, 28, 32), // Responsive text style
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}
 

}

