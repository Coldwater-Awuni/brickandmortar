import 'package:flutter/material.dart';

class SubscriptionSection extends StatelessWidget {
  const SubscriptionSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Get the screen size
    final Size screenSize = MediaQuery.of(context).size;
    
    // Determine if the layout should be vertical (for narrow screens)
    bool isVerticalLayout = screenSize.width < 600;

    return Container(
      constraints: const BoxConstraints(
        minHeight: 200, // Minimum height to ensure content visibility
        maxHeight: 400, // Maximum height to prevent excessive vertical stretching
      ),
      color: Colors.black,
      child: Padding(
        padding: EdgeInsets.all(screenSize.width * 0.05), // Responsive padding
        child: isVerticalLayout
            ? _buildVerticalLayout(context)
            : _buildHorizontalLayout(context),
      ),
    );
  }

  Widget _buildHorizontalLayout(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Expanded(
          flex: 1,
          child: Image.asset(
            'assets/img/accentchair.png',
            fit: BoxFit.contain,
          ),
        ),
        SizedBox(width: 20),
        Expanded(
          flex: 2,
          child: _buildSubscriptionContent(context),
        ),
      ],
    );
  }

  Widget _buildVerticalLayout(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          'assets/img/accentchair.png',
          height: 100,
          fit: BoxFit.contain,
        ),
        SizedBox(height: 20),
        _buildSubscriptionContent(context),
      ],
    );
  }

  Widget _buildSubscriptionContent(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Get new products and promotions in your inbox.',
          style: TextStyle(
            color: Colors.white,
            fontSize: MediaQuery.of(context).size.width * 0.02, // Responsive font size
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              flex: 2,
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Your email',
                  hintStyle: TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 10.0,
                    horizontal: 20.0,
                  ),
                ),
              ),
            ),
            SizedBox(width: 10),
            ElevatedButton(
              onPressed: () {
                // Handle subscribe action
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFFe6cbc2),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
                padding: const EdgeInsets.symmetric(
                  vertical: 15.0,
                  horizontal: 20.0,
                ),
              ),
              child: Text(
                'SUBSCRIBE',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: MediaQuery.of(context).size.width * 0.02, // Responsive font size
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}