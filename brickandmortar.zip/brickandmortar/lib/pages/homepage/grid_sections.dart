import 'package:flutter/material.dart';

import '../../constants/grid_data.dart';
import '../../utils/responsive.dart';
import '../../widgets/grids/homepage_grid.dart';

class grid_sections extends StatelessWidget {
  final List<Map<String, String>> bundle;

  const grid_sections({
    super.key, required this.bundle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ResponsiveWidget(
        largeScreen: bundlegrids(
            bundles: bundle,
            crossAxisCount: 6), // Changed to 6 columns for large screens
        mediumScreen: bundlegrids(
            bundles: bundle,
            crossAxisCount: 3), // Changed to 3 columns for medium screens
        smallScreen: bundlegrids(
            bundles: bundle, crossAxisCount: 2), // 1 column for small screens
      ),
    );
    ;
  }
}
