import 'package:flutter/material.dart';
import 'dart:html' as html;
import 'dart:ui_web' as ui;

class SocialMediaEmbedContainer extends StatefulWidget {
  final String embedUrl;
  final double width;
  final double height;

  const SocialMediaEmbedContainer({
    Key? key,
    required this.embedUrl,
    this.width = 350,
    this.height = 450,
  }) : super(key: key);

  @override
  _SocialMediaEmbedContainerState createState() => _SocialMediaEmbedContainerState();
}

class _SocialMediaEmbedContainerState extends State<SocialMediaEmbedContainer> {
  late String viewId;

  @override
  void initState() {
    super.initState();
    viewId = 'embed-${UniqueKey().toString()}';
    _registerHtmlView();
  }

  void _registerHtmlView() {
    final iframeElement = html.IFrameElement()
      ..src = widget.embedUrl
      ..style.border = 'none'
      ..allowFullscreen = true
      ..width = '100%'
      ..height = '100%';

    // Register the view factory with a unique id
    ui.platformViewRegistry.registerViewFactory(viewId, (int viewId) => iframeElement);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width,
      height: widget.height,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: HtmlElementView(viewType: viewId),
      ),
    );
  }
}