import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class FirstSection extends StatelessWidget {
  final String imagePath;

  const FirstSection({
    
     required this.imagePath,

  });

   



  @override
  Widget build(BuildContext context) {
      var screenSize = MediaQuery.of(context).size;
     return Container(
    width: screenSize.width,
    height: screenSize.height * 0.8, // Cover 80% of the view height
    decoration: BoxDecoration(
      image: DecorationImage(
        image: AssetImage(imagePath),
        fit: BoxFit.cover,
      ),
    ),
    child: Stack(
      children: [
        Center(
          widthFactor: 50,
          heightFactor: 50,
          // top: 50,
          // left: 50,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Set the scene.',
                
                style: _responsiveTextStyle(context, 18, 24, 32), 
                // Responsive text style
              ),
              const SizedBox(height: 10),

              ElevatedButton(
                
                onPressed: () {
                  // Handle button press
                 context.goNamed('Products');
                },
                style: ElevatedButton.styleFrom(
                  padding: _responsivePadding(context, 8, 12, 16), // Responsive padding
                  
                ),
                child: Text(
                  'Explore',
                  style: _responsiveTextStyle(context, 12, 14, 16), // Responsive text style
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
  
  }
  


  TextStyle _responsiveTextStyle(BuildContext context, double small, double medium, double large) {
  double width = MediaQuery.of(context).size.width;
  if (width > 1200) {
    return TextStyle(fontSize: large);
  } else if (width >= 800) {
    return TextStyle(fontSize: medium);
  } else {
    return TextStyle(fontSize: small);
  }
}
EdgeInsets _responsivePadding(BuildContext context, double small, double medium, double large) {
  double width = MediaQuery.of(context).size.width;
  if (width > 1200) {
    return EdgeInsets.symmetric(vertical: large, horizontal: large * 2);
  } else if (width >= 800) {
    return EdgeInsets.symmetric(vertical: medium, horizontal: medium * 2);
  } else {
    return EdgeInsets.symmetric(vertical: small, horizontal: small * 2);
  }
}


}