
// import 'package:brickandmortar/models/productcard.dart';
// import 'package:brickandmortar/utils/productFilter.dart';
// import 'package:brickandmortar/utils/responsive.dart';
// import 'package:flutter/material.dart';
// import '../models/product.dart';



// class ProductFilterPage extends StatefulWidget {
//   final List<String>? initialProduct;
//   final List<String>? initialRooms;

//   ProductFilterPage({
//     Key? key,
//     this.initialProduct,
//     this.initialRooms,
//   }) : super(key: key);

//   @override
//   _ProductFilterPageState createState() => _ProductFilterPageState();
// }

// class _ProductFilterPageState extends State<ProductFilterPage> {
//   late List<String> selectedCategories;
//   late List<String> selectedRooms;
//   List<String> selectedColors = [];
//   List<Product> filteredProducts = [];
//   bool isFilterVisible = true;

//   @override
//   void initState() {
//     super.initState();
//     selectedCategories = widget.initialProduct ?? [];
//     selectedRooms = widget.initialRooms ?? []; // Initialize with the provided rooms
//     updateFilteredProducts(); // Initialize filtered products based on the default selected room
//   }

//   void updateFilteredProducts() {
//     setState(() {
//       filteredProducts = products.where((product) {
//         final matchesCategory = selectedCategories.isEmpty || selectedCategories.contains(product.category);
//         final matchesRoom = selectedRooms.isEmpty || selectedRooms.contains(product.room);
//         final matchesColor = selectedColors.isEmpty || selectedColors.any((color) => product.colors.contains(color));
//         return matchesCategory && matchesRoom && matchesColor;
//       }).toList();
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     final screenWidth = MediaQuery.of(context).size.width;

//     // Reset isFilterVisible for medium and large screens
//     if (!ResponsiveWidget.isSmallScreen(context)) {
//       isFilterVisible = true;
//     }

//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Product Filter'),
//       ),
//       body: Stack(
//         children: [
//           Row(
//             children: [
//               if (!ResponsiveWidget.isSmallScreen(context) || isFilterVisible)
//                 Container(
//                   width: ResponsiveWidget.isSmallScreen(context) ? screenWidth : screenWidth * 0.2, // 20% of the screen width
//                   child: ListView(
//                     children: [
//                       FilterSection(
//                         title: 'Product',
//                         options: ['Bench', 'Chaise Lounge', 'Modular', 'Tables', 'Chairs', 'Sectional', 'Sofas', 'Sofa Bed'],
//                         selectedOptions: selectedCategories,
//                         onOptionSelected: (option) {
//                           setState(() {
//                             if (selectedCategories.contains(option)) {
//                               selectedCategories.remove(option);
//                             } else {
//                               selectedCategories.add(option);
//                             }
//                             updateFilteredProducts();
//                           });
//                         },
//                       ),
//                       FilterSection(
//                         title: 'Room',
//                         options: ['Bedroom', 'Decor', 'Living Room', 'Outdoor'],
//                         selectedOptions: selectedRooms,
//                         onOptionSelected: (option) {
//                           setState(() {
//                             if (selectedRooms.contains(option)) {
//                               selectedRooms.remove(option);
//                             } else {
//                               selectedRooms.add(option);
//                             }
//                             updateFilteredProducts();
//                           });
//                         },
//                       ),
//                       FilterSection(
//                         title: 'Color',
//                         options: const ['White', 'Black', 'Gray', 'Green', 'Blue', 'Beige'],
//                         selectedOptions: selectedColors,
//                         onOptionSelected: (option) {
//                           setState(() {
//                             if (selectedColors.contains(option)) {
//                               selectedColors.remove(option);
//                             } else {
//                               selectedColors.add(option);
//                             }
//                             updateFilteredProducts();
//                           });
//                         },
//                       ),
//                     ],
//                   ),
//                 ),
//               Expanded(
//                 flex: 1,
//                 child: ResponsiveWidget(
//                   largeScreen: ProductGrid(products: filteredProducts, crossAxisCount: 4),
//                   mediumScreen: ProductGrid(products: filteredProducts, crossAxisCount: 3),
//                   smallScreen: ProductGrid(products: filteredProducts, crossAxisCount: 2),
//                 ),
//               ),
//             ],
//           ),
//           if (ResponsiveWidget.isSmallScreen(context))
//             Positioned(
//               top: 10,
//               right: 10,
//               child: FloatingActionButton(
//                 onPressed: () {
//                   setState(() {
//                     isFilterVisible = !isFilterVisible;
//                   });
//                 },
//                 child: Icon(isFilterVisible ? Icons.close : Icons.filter_list),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
// }

// class ProductGrid extends StatelessWidget {
//   final List<Product> products;
//   final int crossAxisCount;

//   const ProductGrid({
//     Key? key,
//     required this.products,
//     required this.crossAxisCount,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return GridView.builder(
//       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//         crossAxisCount: crossAxisCount,
//         childAspectRatio: 1.0,
//         crossAxisSpacing: 10,
//         mainAxisSpacing: 30,
//       ),
//       itemCount: products.length,
//       itemBuilder: (context, index) {
//         return ProductCard(product: products[index]);
//       },
//     );
//   }
// }

