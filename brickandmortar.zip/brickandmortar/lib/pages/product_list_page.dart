// lib/pages/product_list_page.dart
import 'package:brickandmortar/models/productcard.dart';
import 'package:brickandmortar/pages/cart_Page.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';

import '../models/product.dart';
import 'cart_page.dart';

class ProductListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product List'),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.pushNamed(context, '/cartPage');
            },
          ),
          Consumer<CartProvider>(
            builder: (context, cartProvider, child) {
              return Center(
                child: Text(
                  '${cartProvider.getItemCount()}',
                  style: TextStyle(fontSize: 18),
                ),
              );
            },
          ),
        ],
      ),
      body: ListView(
        children: products.map((product) => ProductCard(product: product)).toList(),
      ),
    );
  }
}
