// import 'package:brickandmortar/models/product.dart';
// import 'package:brickandmortar/models/productcard.dart';
// import 'package:flutter/material.dart';

// class ProductGrid extends StatelessWidget {
//   final int crossAxisCount;
//   final List<String> selectedCategories;
//   final List<String> selectedRooms;
//   final List<String> selectedColors;

//   ProductGrid({
//     required this.crossAxisCount,
//     required this.selectedCategories,
//     required this.selectedRooms,
//     required this.selectedColors,
//   });

//   List<Product> getFilteredProducts() {
    
//     return products.where((product) {
//       bool matchesCategory = selectedCategories.isEmpty ||
//           selectedCategories.any((category) => product.name.contains(category));
//       bool matchesRoom = selectedRooms.isEmpty || selectedRooms.contains(product.name); 
//       bool matchesColor = selectedColors.isEmpty ||
//           selectedColors.any((color) => product.colors.contains(color));

//       return matchesCategory && matchesRoom && matchesColor;
//     }).toList();
//   }

//   @override
//   Widget build(BuildContext context) {
//     List<Product> filteredProducts = getFilteredProducts();
      
//     return GridView.builder(
//       padding: const EdgeInsets.all(10),
//       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//         crossAxisCount: crossAxisCount,
//         childAspectRatio: 1.0,
//         crossAxisSpacing: 10,
//         mainAxisSpacing: 30,
//       ),
//       itemCount: filteredProducts.length,
//       itemBuilder: (context, index) {
//                 Product product = products[index];
//                 if ((selectedCategories.isEmpty || selectedCategories.contains(product.category)) &&
//                     (selectedRooms.isEmpty || selectedRooms.contains(product.room)) &&
//                     (selectedColors.isEmpty || selectedColors.any((color) => product.colors.contains(color)))) {
//                   return ProductCard(product: product);
//                 }
//                      return Container();
//               },
//     );
//   }
// }



import 'package:flutter/material.dart';

import '../../models/product.dart';
import '../../models/productcard.dart';

class ProductGrid extends StatelessWidget {
  final List<Product> products;
  final int crossAxisCount;

  const ProductGrid({
    Key? key,
    required this.products,
    required this.crossAxisCount,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return GridView.builder(
          shrinkWrap: true,
          physics: const AlwaysScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            childAspectRatio: 1.0,
            crossAxisSpacing: 10,
            mainAxisSpacing: 30,
          ),
          itemCount: products.length,
          itemBuilder: (context, index) {
            return ProductCard(product: products[index]);
          },
        );
      },
    );
  }
}
