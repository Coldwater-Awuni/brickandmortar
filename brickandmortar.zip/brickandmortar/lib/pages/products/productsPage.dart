import 'package:brickandmortar/widgets/newNavbar.dart';
import 'package:flutter/material.dart';

import '../../models/product.dart';
import '../../utils/productFilter.dart';

import '../../utils/responsive.dart';

import '../../widgets/cartpage/cart_sidebar.dart';

import '../../widgets/navigationbar.dart';
import '../../widgets/sideNivigationBar.dart';

import 'productgrid.dart';

/// Product filter page for the e-commerce app.
/// Displays products based on selected categories, rooms, and colors.
class ProductFilterPage extends StatefulWidget {
  final List<String>? initialProduct;
  final List<String>? initialRooms;

  const ProductFilterPage({
    Key? key,
    this.initialProduct,
    this.initialRooms,
  }) : super(key: key);

  @override
  _ProductFilterPageState createState() => _ProductFilterPageState();
}

class _ProductFilterPageState extends State<ProductFilterPage> {
  late List<String> selectedCategories;
  late List<String> selectedRooms;
  List<String> selectedColors = [];
  List<Product> filteredProducts = [];

  @override
  void initState() {
    super.initState();
    // Initialize selected filters with provided initial values.
    selectedCategories = widget.initialProduct ?? [];
    selectedRooms = widget.initialRooms ?? [];
    updateFilteredProducts();
  }

  /// Updates the list of filtered products based on selected filters.
  void updateFilteredProducts() {
    setState(() {
      filteredProducts = products.where((product) {
        final matchesCategory = selectedCategories.isEmpty || selectedCategories.contains(product.category);
        final matchesRoom = selectedRooms.isEmpty || selectedRooms.contains(product.room);
        final matchesColor = selectedColors.isEmpty || selectedColors.any((color) => product.colors.contains(color));
        return matchesCategory && matchesRoom && matchesColor;
      }).toList();
    });
  }

  /// Builds the content for the filter section.
  Widget buildFilterContent() {
    return ListView(
      children: [
       SizedBox(height: 20,),
        Center(
          child: const Text(
            'Filter Products',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 15,
            ),
          ),
        ),
        FilterSection(
          title: 'Product',
          options: ['Bench', 'Chaise Lounge', 'Modular', 'Tables', 'Chairs', 'Sectional', 'Sofas', 'Sofa Bed'],
          selectedOptions: selectedCategories,
          onOptionSelected: (option) {
            setState(() {
              toggleSelection(selectedCategories, option);
              updateFilteredProducts();
            });
          },
        ),
        FilterSection(
          title: 'Room',
          options: ['Bedroom', 'Decor', 'Living Room', 'Outdoor'],
          selectedOptions: selectedRooms,
          onOptionSelected: (option) {
            setState(() {
              toggleSelection(selectedRooms, option);
              updateFilteredProducts();
            });
          },
        ),
        FilterSection(
          title: 'Color',
          options: ['White', 'Black', 'Gray', 'Green', 'Blue', 'Beige'],
          selectedOptions: selectedColors,
          onOptionSelected: (option) {
            setState(() {
              toggleSelection(selectedColors, option);
              updateFilteredProducts();
            });
          },
        ),
      ],
    );
  }

  /// Toggles the selection of a filter option.
  void toggleSelection(List<String> list, String option) {
    if (list.contains(option)) {
      list.remove(option);
    } else {
      list.add(option);
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = ResponsiveWidget.isSmallScreen(context);

    return Scaffold(
      drawer:  NavDrawer(),
      endDrawer: isSmallScreen ? Drawer(child: buildFilterContent()) :  CartSidebar(),
      body: Column(
        children: [
           Navbarnew(),
          const Text(
            'Products',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          Expanded(
            child: Row(
              children: [
                if (!isSmallScreen)
                  Container(
                    width: screenWidth * 0.2,
                    child: buildFilterContent(),
                  ),
                Expanded(
                  child: ResponsiveWidget(
                    largeScreen: ProductGrid(products: filteredProducts, crossAxisCount: 4),
                    mediumScreen: ProductGrid(products: filteredProducts, crossAxisCount: 3),
                    smallScreen: ProductGrid(products: filteredProducts, crossAxisCount: 2),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: isSmallScreen
          ? Builder(
              builder: (BuildContext context) {
                return FloatingActionButton(
                  onPressed: () => Scaffold.of(context).openEndDrawer(),
                  child: const Icon(Icons.filter_list),
                );
              },
            )
          : null,
    );
  }
}
