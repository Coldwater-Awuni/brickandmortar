import 'package:brickandmortar/widgets/cartpage/cart_sidebar.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/product.dart';
import '../../providers/cart_provider.dart';
import 'package:brickandmortar/widgets/newNavbar.dart';
import 'package:brickandmortar/widgets/sideNivigationBar.dart';

class ProductDetailPage extends StatefulWidget {
  final Product product;

  ProductDetailPage({required this.product});

  @override
  _ProductDetailPageState createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  late String _selectedImage;

  @override
  void initState() {
    super.initState();
    _selectedImage = widget.product.primaryImage;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: NavDrawer(),
      endDrawer: CartSidebar(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Navbarnew(),
            const SizedBox(height: 10),
            const Text(
              'Product Details',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            LayoutBuilder(
              builder: (context, constraints) {
                return constraints.maxWidth > 800
                    ? _buildWideLayout()
                    : _buildNarrowLayout();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWideLayout() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 3,
            child: Image.asset(_selectedImage, fit: BoxFit.cover),
          ),
          const SizedBox(width: 30),
          Expanded(
            flex: 4,
            child: _buildProductDetails(),
          ),
        ],
      ),
    );
  }

  Widget _buildNarrowLayout() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.asset(_selectedImage, fit: BoxFit.cover),
          const SizedBox(height: 20),
          _buildProductDetails(),
        ],
      ),
    );
  }

  Widget _buildProductDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.product.name,
          style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(
          '\$${widget.product.price.toStringAsFixed(2)}',
          style: const TextStyle(fontSize: 22, color: Colors.red),
        ),
        const SizedBox(height: 16),
        const Text(
          'Description',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(widget.product.description),
        const SizedBox(height: 16),
        const Text(
          'Specifications',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        ..._buildSpecifications(),
        const SizedBox(height: 16),
        const Text(
          'Available Colors',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        _buildColorOptions(),
        const SizedBox(height: 16),
        Center(
          child: ElevatedButton(
            onPressed: _addToCart,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              textStyle: const TextStyle(fontSize: 24),
            ),
            child: const Text('Add to Cart'),
          ),
        ),
      ],
    );
  }

  List<Widget> _buildSpecifications() {
    return widget.product.specifications.entries.map((entry) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              entry.key,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            Text(entry.value),
          ],
        ),
      );
    }).toList();
  }

  Widget _buildColorOptions() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: widget.product.colors.map((color) {
        return GestureDetector(
          onTap: () => _selectColor(color),
          child: MouseRegion(
            cursor: SystemMouseCursors.click,
            child: Container(
              height: 30,
              width: 30,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _getColorFromString(color),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.5,
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  void _selectColor(String color) {
    setState(() {
      _selectedImage =
          widget.product.colorImageMap[color] ?? widget.product.primaryImage;
    });
  }

  void _addToCart() {
    Provider.of<CartProvider>(context, listen: false)
        .addToCart(widget.product);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('${widget.product.name} added to cart'),
      duration: const Duration(seconds: 2),
      action: SnackBarAction(
        label: 'View Cart',
        onPressed: () {
          // Navigate to cart page or perform another action
        },
      ),
    ));
  }

  Color _getColorFromString(String color) {
    switch (color) {
      case 'White':
        return Colors.white;
      case 'Black':
        return Colors.black;
      case 'Gray':
        return Colors.grey;
      case 'Green':
        return Colors.green;
      case 'Blue':
        return Colors.blue;
      case 'Beige':
        return Colors.brown;
      case 'Yellow':
        return Colors.yellow;
      case 'Red':
        return Colors.red;
      default:
        return Colors.transparent;
    }
  }
}
