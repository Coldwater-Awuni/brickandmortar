import 'package:brickandmortar/constants/submenudata.dart';
import 'package:brickandmortar/utils/responsive.dart';
import 'package:brickandmortar/widgets/menus.dart';
import 'package:brickandmortar/widgets/navigationbar.dart';
import 'package:brickandmortar/widgets/newNavbar.dart';
import 'package:brickandmortar/widgets/sideNivigationBar.dart';
import 'package:flutter/material.dart';


class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: NavDrawer(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Navbarnew(),
            const SizedBox(height: 20),
            const Text(
              "About us",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 30,
              ),
            ),
            const SizedBox(height: 20),
            ResponsiveWidget(
              largeScreen: _buildLargeScreen(),
              mediumScreen: _buildMediumScreen(),
              smallScreen: _buildSmallScreen(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLargeScreen() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(90.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 600,
              child: Image.asset(
                'img/slider/slide1.jpg',
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(child: _buildCompanyInfo()
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMediumScreen() {
    return Padding(
      padding: const EdgeInsets.all(40.0),
      child: Column(
        children: [
          Container(
            width: 500,
            child: Image.asset(
              'img/slider/slide1.jpg',
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(height: 16),
          _buildCompanyInfo(),
        ],
      ),
    );
  }

  Widget _buildSmallScreen() {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        children: [
          Container(
            width: 300,
            child: Image.asset(
              'img/slider/slide1.jpg',
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(height: 16),
          _buildCompanyInfo(),
        ],
      ),
    );
  }

  Widget _buildCompanyInfo() {
    return const Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Brick and Mortar Decor Ltd',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        SizedBox(height: 8),
        Text(
          'is dedicated to transforming empty spaces into cozy homes by offering a range of modern, elegant, and affordable furniture and decor.',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
        SizedBox(height: 16),
        Text(
          'Our mission is to provide individuals with the opportunity to create a sanctuary, filled with simplicity and tranquility, where they can find solace in their surroundings.',
          style: TextStyle(
            fontSize: 16,
          ),
        ),
      ],
    );
  }
}