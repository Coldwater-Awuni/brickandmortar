// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../providers/dashboard_provider.dart';
// import '../widgets/product_list.dart';
// import '../widgets/statistics_card.dart';
// import '../widgets/user_info_card.dart';

// class DashboardScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('E-commerce Dashboard'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(8.0),
//         child: Column(
//           children: [
//             StatisticsCard(),
//             UserInfoCard(),
//             Expanded(child: ProductList()),
//           ],
//         ),
//       ),
//     );
//   }
// }
