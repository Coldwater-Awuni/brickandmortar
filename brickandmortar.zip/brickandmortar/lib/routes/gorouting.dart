import 'package:brickandmortar/pages/products/productsPage.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:brickandmortar/pages/about.dart';
import 'package:brickandmortar/pages/cart_Page.dart';
import 'package:brickandmortar/pages/homepage.dart';
import 'package:brickandmortar/pages/product_list_page.dart';


  final GoRouter _router = GoRouter(
  routes: <RouteBase>[
    GoRoute(
      path: '/',
      name: 'Home',
      builder: (BuildContext context, GoRouterState state) => HomeScreen(),
    ),
    GoRoute(
      path: '/productList',
      name: 'Products',
      builder: (BuildContext context, GoRouterState state) => ProductFilterPage(),
    ),
    GoRoute(
      path: '/bedroom',
      name: 'Bedroom',
      builder: (BuildContext context, GoRouterState state) => 
        ProductFilterPage(initialRooms: const ['Bedroom']),
    ),
    GoRoute(
      path: '/living-room',
      name: 'livingroom',
      builder: (BuildContext context, GoRouterState state) => 
        ProductFilterPage(initialRooms: const ['Living Room']),
    ),
    GoRoute(
      path: '/Sofas',
      name: 'Sofas',
      builder: (BuildContext context, GoRouterState state) => 
        ProductFilterPage(initialProduct: ['Sofas']),
    ),
    GoRoute(
      path: '/Tables',
      name: 'Tables',
      builder: (BuildContext context, GoRouterState state) => 
        ProductFilterPage(initialProduct: ['Tables']),
    ),
    GoRoute(
      path: '/Chairs',
      name: 'Chairs',
      builder: (BuildContext context, GoRouterState state) => 
        ProductFilterPage(initialProduct: ['Chairs']),
    ),
    GoRoute(
      path: '/cartPage',
      name: 'cartpage',
      builder: (BuildContext context, GoRouterState state) => CartPage(),
    ),
    GoRoute(
      path: '/about',
      name: 'about',
      builder: (BuildContext context, GoRouterState state) => AboutPage(),
    ),
  ],
);
  
// Export the router for use in other files
GoRouter get router => _router;