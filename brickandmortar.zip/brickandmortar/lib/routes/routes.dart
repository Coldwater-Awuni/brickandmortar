// import 'package:brickandmortar/pages/about.dart';
// import 'package:brickandmortar/pages/cart_Page.dart';
// import 'package:brickandmortar/pages/homepage.dart';
// import 'package:brickandmortar/pages/product_list_page.dart';
// import 'package:brickandmortar/pages/products/productsPage.dart';
// import 'package:flutter/material.dart';
// import 'package:brickandmortar/pages/productpag.dart';

// class Routes {
  
//   static final Map<String, WidgetBuilder> routes = {
//   //  '/productPages': (context) => ProductPage() ,
//    'productList' : (context) => ProductFilterPage(),
//    '/bedroom' :(context) => ProductFilterPage(initialRooms: const ['Bedroom'],),
//     '/living-room' :(context) => ProductFilterPage(initialRooms: const ['Living Room'],),
//    '/Sofas' :(context) => ProductFilterPage(initialProduct: ['Sofas'],),
//     '/Tables' :(context) => ProductFilterPage(initialProduct: ['Tables'],),
//      '/Chairs' :(context) => ProductFilterPage(initialProduct: ['Chairs'],),
//     '/cartPage': (context) => CartPage(),
//     '/about': (context) => AboutPage(),
//      '/homePage': (context) => HomeScreen(),
//   };
// }
