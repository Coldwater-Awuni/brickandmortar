import 'package:flutter/foundation.dart';
import '../models/cart.dart';
import '../models/product.dart';


class CartProvider with ChangeNotifier {
  final Cart _cart = Cart();

  Cart get cart => _cart;

  void addToCart(Product product) {
    _cart.addProduct(product);
    notifyListeners();
  }

  void removeFromCart(Product product) {
    _cart.removeProduct(product);
    notifyListeners();
  }

  void updateQuantity(Product product, int newQuantity) {
    if (newQuantity <= 0) {
      removeFromCart(product);
    } else {
      int index = _cart.items.indexWhere((item) => item.product.id == product.id);
      if (index != -1) {
        _cart.items[index] = CartItem(product: product, quantity: newQuantity);
        notifyListeners();
      }
    }
  }

  void clearCart() {
    _cart.clear();
    notifyListeners();
  }

  double getTotalPrice() {
    return _cart.getTotalPrice();
  }

  double getSubtotal() {
    return _cart.items.fold(0, (sum, item) => sum + (item.product.price * item.quantity));
  }

  double getShippingCost() {
    // Implement your shipping cost logic here
    // For now, we'll return 0 for free shipping
    return 0;
  }

  int getItemCount() {
    return _cart.items.length;
  }

  int getTotalQuantity() {
    return _cart.items.fold(0, (sum, item) => sum + item.quantity);
  }

  bool get isEmpty => _cart.items.isEmpty;
}