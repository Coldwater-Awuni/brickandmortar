// import 'package:flutter/material.dart';
// import '../models/product.dart';

// class DashboardProvider with ChangeNotifier {
//   List<Product> _products = [
//     Product(id: 'p1', name: 'Product 1', price: 29.99, imageUrl: 'assets/product1.png'),
//     Product(id: 'p2', name: 'Product 2', price: 59.99, imageUrl: 'assets/product2.png'),
//     // Add more products
//   ];

//   List<Product> get products {
//     return [..._products];
//   }


// }
