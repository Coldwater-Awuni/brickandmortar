// lib/models/product.dart


class Product {
  String id;
  String name;
  double price;
  String primaryImage;
  String secondaryImage;
  List<String>? complementaryImages;
  List<String> colors;
  String category;
  String room;
  bool isNew;
  String description;
  Map<String, String> specifications;
  Map<String, String> colorImageMap;

  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.primaryImage,
    required this.secondaryImage,
    this.complementaryImages,
    required this.colors,
    required this.category,
    required this.room,
    required this.isNew,
    required this.description,
    required this.specifications,
    required this.colorImageMap,
  }
  );

}
// Sample data
List<Product> products = [
  Product(
    id: "1",
    name: "Timber 90\" Sofa - Olio Green",
    price: 2000,
    primaryImage: "assets/img/pri-img.jpg",
    secondaryImage: "assets/img/sec-img.jpg",
    colorImageMap: {
      "Green": "assets/products/greenSofa.jpg",
      "Gray": "assets/img/third-img.jpg",
      "Beige": "assets/products/beigeSofa.jpg",
    },
    colors: ["Green", "Gray", "Beige"],
    category: "Sofas",
    room: "Living Room",
    description:
        "This Timber Sofa is the epitome of style and comfort. Perfect for any living room setup.",
    specifications: {
      "Material": "Wood and Fabric",
      "Dimensions": "90\" W x 40\" D x 35\" H",
      "Weight": "120 lbs",
    },
    isNew: true,
  ),
  Product(
    id: "2",
    name: "Timber 90\" Sofa - Olio Green",
    price: 1299,
    primaryImage: "assets/img/pri-img.jpg",
    secondaryImage: "assets/img/sec-img.jpg",
    colorImageMap: {
      "Green": "products/greenSofa.jpg",
      "Gray": "assets/img/third-img.jpg",
      "Beige": "products/beigeSofa.jpg",
    },
    colors: ["Green", "Gray", "Beige"],
    category: "Sofas",
    room: "Living Room",
    description:
        "This Timber Sofa is the epitome of style and comfort. Perfect for any living room setup.",
    specifications: {
      "Material": "Wood and Fabric",
      "Dimensions": "90\" W x 40\" D x 35\" H",
      "Weight": "120 lbs",
    },
    isNew: true,
  ),
  Product(
    id: "3",
    name: "Sofa 90\" Sofa - Olio Green",
    price: 1299,
    primaryImage: "assets/img/pri-img.jpg",
    secondaryImage: "assets/img/sec-img.jpg",
    colorImageMap: {
      "Green": "assets/products/greenSofa.jpg",
      "Gray": "assets/img/third-img.jpg",
      "Beige": "assets/products/beigeSofa.jpg",
    },
    colors: ["Green", "Gray", "Beige"],
    category: "Chairs",
    room: "Living Room",
    description:
        "This Timber Sofa is the epitome of style and comfort. Perfect for any living room setup.",
    specifications: {
      "Material": "Wood and Fabric",
      "Dimensions": "90\" W x 40\" D x 35\" H",
      "Weight": "120 lbs",
    },
    isNew: false,
  ),
  Product(
    id: "4",
    name: "Sofa 90\" Sofa - Olio Green",
    price: 1299,
    primaryImage: "assets/img/pri-img.jpg",
    secondaryImage: "assets/img/sec-img.jpg",
    colorImageMap: {
      "Green": "assets/products/greenSofa.jpg",
      "Gray": "assets/img/third-img.jpg",
      "Beige": "assets/products/beigeSofa.jpg",
    },
    colors: ["Green", "Gray", "Beige"],
    category: "Chairs",
    room: "Bedroom",
    description:
        "This Timber Sofa is the epitome of style and comfort. Perfect for any living room setup.",
    specifications: {
      "Material": "Wood and Fabric",
      "Dimensions": "90\" W x 40\" D x 35\" H",
      "Weight": "120 lbs",
    },
    isNew: false,
  ),
  Product(
    id: "5",
    name: "Sofa 90\" Sofa - Olio Green",
    price: 1299,
    primaryImage: "assets/img/pri-img.jpg",
    secondaryImage: "assets/img/sec-img.jpg",
    colorImageMap: {
      "Green": "assets/products/greenSofa.jpg",
      "Gray": "assets/img/third-img.jpg",
      "Beige": "assets/products/beigeSofa.jpg",
    },
    colors: ["Green", "Gray", "Beige"],
    category: "Tables",
    room: "Bedroom",
    description:
        "This Timber Sofa is the epitome of style and comfort. Perfect for any living room setup.",
    specifications: {
      "Material": "Wood and Fabric",
      "Dimensions": "90\" W x 40\" D x 35\" H",
      "Weight": "120 lbs",
    },
    isNew: false,
  ),
  // Add more products here...
];
