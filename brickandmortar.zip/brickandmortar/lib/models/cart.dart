// lib/models/cart.dart
import 'product.dart';

/// Represents an item in the cart.
class CartItem {
  final Product product;
  int quantity;

  CartItem({
    required this.product,
    this.quantity = 1,
  });
}

/// Represents the shopping cart.
class Cart {
  final List<CartItem> items = [];

  /// Adds a product to the cart. If the product already exists, increases the quantity.
  void addProduct(Product product) {
    for (var item in items) {
      if (item.product.id == product.id) {  // Use product ID for comparison
        item.quantity++;
        return;
      }
    }
    items.add(CartItem(product: product));
  }

  /// Removes a product from the cart.
  void removeProduct(Product product) {
    items.removeWhere((item) => item.product.id == product.id);  // Use product ID for comparison
  }

  /// Clears the cart.
  void clear() {
    items.clear();
  }

  /// Gets the total price of all items in the cart.
  double getTotalPrice() {
    return items.fold(0.0, (total, item) => total + item.product.price * item.quantity);
  }
}
