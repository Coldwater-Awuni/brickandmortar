import 'package:brickandmortar/pages/products/productDetail.dart';
import 'package:brickandmortar/providers/cart_provider.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';

class ProductCard extends StatefulWidget {
  final Product product;

  ProductCard({required this.product});

  @override
  _ProductCardState createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard> {
  bool _isHovering = false;
  String _hoveredColor = '';
  late String _displayedImage;

  @override
  void initState() {
    super.initState();
    _displayedImage = widget.product.primaryImage;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => _navigateToDetailPage(context),
              child: MouseRegion(
                cursor: SystemMouseCursors.click,
                onEnter: (_) => _onHover(true),
                onExit: (_) => _onHover(false),
                child: Stack(
                  children: [
                    _buildProductImage(),
                    if (widget.product.isNew) _buildNewLabel(),
                    _buildAddToCartButton(context),
                  ],
                ),
              ),
            ),
          ),
          _buildProductName(context),
          _buildProductPrice(),
          _buildColorOptions(),
        ],
      ),
    );
  }

  void _onHover(bool isHovering) {
    setState(() {
      _isHovering = isHovering;
      _displayedImage = isHovering
          ? widget.product.secondaryImage
          : widget.product.primaryImage;
    });
  }

  Widget _buildProductImage() {
    return Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage(_displayedImage),
          fit: BoxFit.contain,
        ),
      ),
    );
  }

  Widget _buildNewLabel() {
    return Positioned(
      top: 8,
      left: 8,
      child: Container(
        color: Colors.red,
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
        child: const Text('NEW', style: TextStyle(color: Colors.white)),
      ),
    );
  }

  Widget _buildAddToCartButton(BuildContext context) {
    return Positioned(
      bottom: 8,
      right: 8,
      child: IconButton(
        icon: const FaIcon(FontAwesomeIcons.bagShopping),
        mouseCursor: SystemMouseCursors.click,
        hoverColor: Colors.redAccent,
        tooltip: 'Add to cart',
        onPressed: () {
          Provider.of<CartProvider>(context, listen: false)
              .addToCart(widget.product);

          // Show a SnackBar when an item is added to the cart
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('${widget.product.name} added to cart!'),
              duration: const Duration(seconds: 2),
              action: SnackBarAction(
                label: 'View Cart',
                onPressed: () {
                  // Navigate to cart page or perform another action
                },
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildProductName(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: GestureDetector(
        onTap: () => _navigateToDetailPage(context),
        child: MouseRegion(
          cursor: SystemMouseCursors.click,
          onEnter: (_) => setState(() => _isHovering = true),
          onExit: (_) => setState(() => _isHovering = false),
          child: Center(
            child: Text(
              widget.product.name,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: _isHovering ? Colors.blue : Colors.black,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProductPrice() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Center(
        child: Text(
          '\$${widget.product.price.toStringAsFixed(2)}',
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.red,
          ),
        ),
      ),
    );
  }

  Widget _buildColorOptions() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: widget.product.colors.map((color) {
          return GestureDetector(
            onTap: () => print('Selected color: $color for product ${widget.product.name}'),
            child: MouseRegion(
              cursor: SystemMouseCursors.click,
              onEnter: (_) => _updateImageOnHover(color),
              onExit: (_) => _resetImage(),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 2.0),
                height: 20,
                width: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _getColorFromString(color),
                  border: Border.all(
                    color: _hoveredColor == color ? Colors.blue : Colors.transparent,
                    width: 2,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _navigateToDetailPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProductDetailPage(product: widget.product),
      ),
    );
  }

  void _updateImageOnHover(String color) {
    setState(() {
      _hoveredColor = color;
      _displayedImage = widget.product.colorImageMap[color] ?? widget.product.primaryImage;
    });
  }

  void _resetImage() {
    setState(() {
      _hoveredColor = '';
      _displayedImage = widget.product.primaryImage;
    });
  }

  Color _getColorFromString(String color) {
    switch (color) {
      case 'White':
        return Colors.white;
      case 'Black':
        return Colors.black;
      case 'Gray':
        return Colors.grey;
      case 'Green':
        return Colors.green;
      case 'Blue':
        return Colors.blue;
      case 'Beige':
        return Colors.brown;
      case 'Yellow':
        return Colors.yellow;
      case 'Red':
        return Colors.red;
      default:
        return Colors.transparent;
    }
  }
}
