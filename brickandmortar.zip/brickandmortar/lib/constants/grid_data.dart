 
 final List<Map<String, String>> products = [
      {
        "title": "Chairs ",
        "image": "assets/img/shop_bundles/all_bundles.jpg",
        "route": "Chairs"
      },
      {
        "title": "Tables ",
        "image": "assets/img/shop_bundles/dining_room.jpg",
        "route": "/Tables"
      },
      {
        "title": "Sofas ",
        "image": "assets/img/shop_bundles/bedroom.jpg",
        "route": "Sofas"
      },
      {
        "title": "Fragrances ",
        "image": "assets/img/shop_bundles/home_office.webp",
        "route": "/home-office"
      },
      {
        "title": "Décors ",
        "image": "assets/img/shop_bundles/outdoor.jpg",
        "route": "/productList"
      },
      {
        "title": "Shop All ",
        "image": "assets/img/shop_bundles/all_bundles.jpg",
        "route": "/productPages"
      },
    ];


        final List<Map<String, String>> bundles = [
      {
        "title": "Living Room",
        "image": "assets/img/shop_bundles/all_bundles.jpg",
        "route": "/living-room"
      },
      {
        "title": "Dining Room ",
        "image": "assets/img/shop_bundles/dining_room.jpg",
        "route": "/dining-room"
      },
      {
        "title": "Bedroom Bundles",
        "image": "assets/img/shop_bundles/bedroom.jpg",
        "route": "/bedroom"
      },
      {
        "title": "Home Office  ",
        "image": "assets/img/shop_bundles/home_office.webp",
        "route": "/home-office"
      },
      {
        "title": "Outdoor  ",
        "image": "assets/img/shop_bundles/outdoor.jpg",
        "route": "/outdoor"
      },
      {
        "title": "Shop All ",
        "image": "assets/img/shop_bundles/all_bundles.jpg",
        "route": "/all-bundles"
      },
    ];