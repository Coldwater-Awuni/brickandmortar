 final Map<String, dynamic>   subMenuData = {
     'Home' : {'route':'Home'},
    'Products': [
      {'title': 'Sofas & Sectionals', 'route': 'Sofas'},
      {'title': 'Chairs', 'route': 'chairs'},
      {'title': 'Dining Tables & Desks', 'route': 'dining-tables'},
      {'title': 'Benches', 'route': '/benches'},
      {'title': 'Ottomans', 'route': '/ottomans'},
      {'title': 'Beds & Headboards', 'route': '/beds'},
      {'title': 'Dressers', 'route': '/dressers'},
      {'title': 'Storage Furniture', 'route': '/storage-furniture'},
      {'title': 'Furniture Care Kits', 'route': '/furniture-care'},
      {'title': 'Furniture Bundles', 'route': '/furniture-bundles'}
    ],
    'Rooms': [
      {'title': 'Living Room', 'route': '/living-room'},
      {'title': 'Bedroom', 'route': '/bedroom'},
      {'title': 'Dining Room', 'route': '/dining-room'},
      {'title': 'Home Office', 'route': '/home-office'},
      {'title': 'Entryway', 'route': '/entryway'},
      {'title': 'Kitchen', 'route': '/kitchen'},
      {'title': 'Kids Room', 'route': '/kids-room'}
    ],
    'Outdoor': [
      {'title': 'Outdoor Sets', 'route': '/outdoor-sets'},
      {'title': 'Outdoor Lounge Furniture', 'route': '/outdoor-lounge'},
      {'title': 'Outdoor Dining Furniture', 'route': '/outdoor-dining'},
      {'title': 'Planters & Pots', 'route': '/planters'},
      {'title': 'Outdoor Accessories & Decor', 'route': 'outdoor-accessories'},
      {'title': 'Outdoor Bundles', 'route': 'outdoor-bundles'}
    ],
    // Add a menu without submenus
    'About': { 'route': 'about'},
    
  };