import 'package:flutter/material.dart';

class StatisticsCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Card(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Column(
              children: [
                Text('Sales'),
                SizedBox(height: 8),
                Text('1500', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              ],
            ),
            Column(
              children: [
                Text('Revenue'),
                SizedBox(height: 8),
                Text('\$12000', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
