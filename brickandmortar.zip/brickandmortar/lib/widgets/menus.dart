
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';


class CustomMenuBar extends StatelessWidget {
  final Map<String, dynamic> subMenuData;

  CustomMenuBar({required this.subMenuData});

  // Method to handle menu selection
  void choiceAction(BuildContext context, String route) {
    context.goNamed(route);
  }

  // Method to generate menu items for PopupMenuButton
  List<PopupMenuEntry<String>> _buildMenuItems(BuildContext context, String category) {
    List<PopupMenuEntry<String>> menuItems = [];
    subMenuData[category]?.forEach((item) {
      menuItems.add(
        PopupMenuItem<String>(
          value: item['route'],
          child: MouseRegion(
            cursor: SystemMouseCursors.click,
            child: ListTile(
              title: Text(item['title']!),
            ),
          ),
        ),
      );
    });
    return menuItems;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      
      padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: subMenuData.keys.map((category) {
          return subMenuData[category] is List
              ? PopupMenuButton<String>(
                  offset: Offset(0, 30), // Offset to place submenu below the parent menu
                  onSelected: (route) => choiceAction(context, route),
                  itemBuilder: (context) => _buildMenuItems(context, category),
                  child: MouseRegion(
                    cursor: SystemMouseCursors.click,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text(
                        category,
                        style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                )
              : MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: GestureDetector(
                    onTap: () => choiceAction(context, subMenuData[category]['route']),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text(
                        category,
                        style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                );
        }).toList(),
      ),
    );
  }
}