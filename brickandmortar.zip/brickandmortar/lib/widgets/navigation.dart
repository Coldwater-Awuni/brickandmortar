import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Define routes for navigation
      routes: {
        '/sofas': (context) => ContentScreen(title: 'Sofas & Sectionals'),
        '/chairs': (context) => ContentScreen(title: 'Chairs'),
        '/dining-tables': (context) => ContentScreen(title: 'Dining Tables & Desks'),
        // Add all other routes here...
        '/about': (context) => ContentScreen(title: 'About Us'),
        '/contact': (context) => ContentScreen(title: 'Contact Us'),
      },
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  // Define the subMenuData as a final variable
  final Map<String, dynamic> subMenuData = {
    'Products': [
      {'title': 'Sofas & Sectionals', 'route': '/sofas'},
      {'title': 'Chairs', 'route': '/chairs'},
      {'title': 'Dining Tables & Desks', 'route': '/dining-tables'},
      {'title': 'Benches', 'route': '/benches'},
      {'title': 'Ottomans', 'route': '/ottomans'},
      {'title': 'Beds & Headboards', 'route': '/beds'},
      {'title': 'Dressers', 'route': '/dressers'},
      {'title': 'Storage Furniture', 'route': '/storage-furniture'},
      {'title': 'Furniture Care Kits', 'route': '/furniture-care'},
      {'title': 'Furniture Bundles', 'route': '/furniture-bundles'}
    ],
    'Rooms': [
      {'title': 'Living Room', 'route': '/living-room'},
      {'title': 'Bedroom', 'route': '/bedroom'},
      {'title': 'Dining Room', 'route': '/dining-room'},
      {'title': 'Home Office', 'route': '/home-office'},
      {'title': 'Entryway', 'route': '/entryway'},
      {'title': 'Kitchen', 'route': '/kitchen'},
      {'title': 'Kids Room', 'route': '/kids-room'}
    ],
    'Outdoor': [
      {'title': 'Outdoor Sets', 'route': '/outdoor-sets'},
      {'title': 'Outdoor Lounge Furniture', 'route': '/outdoor-lounge'},
      {'title': 'Outdoor Dining Furniture', 'route': '/outdoor-dining'},
      {'title': 'Planters & Pots', 'route': '/planters'},
      {'title': 'Outdoor Accessories & Decor', 'route': '/outdoor-accessories'},
      {'title': 'Outdoor Bundles', 'route': '/outdoor-bundles'}
    ],
    'About': [
      {'title': 'About Us', 'route': '/about'},
    ],
    // Add a menu without submenus
    'Contact': {'route': '/contact'},
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          CustomMenuBar(subMenuData: subMenuData),
          Expanded(
            child: Center(
              child: Text('Home Screen'),
            ),
          ),
        ],
      ),
    );
  }
}

class CustomMenuBar extends StatefulWidget {
  final Map<String, dynamic> subMenuData;

  CustomMenuBar({required this.subMenuData});

  @override
  _CustomMenuBarState createState() => _CustomMenuBarState();
}

class _CustomMenuBarState extends State<CustomMenuBar> {
  String? hoveredCategory;

  // Method to handle menu selection
  void choiceAction(BuildContext context, String route) {
    Navigator.pushNamed(context, route);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey[200],
      padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: widget.subMenuData.keys.map((category) {
          return MouseRegion(
            onEnter: (_) => setState(() => hoveredCategory = category),
            onExit: (_) => setState(() => hoveredCategory = null),
            cursor: SystemMouseCursors.click,
            child: GestureDetector(
              onTap: () {
                if (widget.subMenuData[category] is Map) {
                  choiceAction(context, widget.subMenuData[category]['route']);
                }
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Column(
                  children: [
                    Text(
                      category,
                      style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                    ),
                    if (hoveredCategory == category && widget.subMenuData[category] is List)
                      _buildSubMenu(context, widget.subMenuData[category])
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildSubMenu(BuildContext context, List<Map<String, String>> subMenuItems) {
    return Material(
      elevation: 4.0,
      child: Container(
        color: Colors.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: subMenuItems.map((item) {
            return InkWell(
              onTap: () => choiceAction(context, item['route']!),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(item['title']!),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class ContentScreen extends StatelessWidget {
  final String title;

  ContentScreen({required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Center(
        child: Text(title),
      ),
    );
  }
}
