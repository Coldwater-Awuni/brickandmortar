import 'package:flutter/material.dart';

class UserInfoCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/user.png'),
        ),
        title: Text('John Doe'),
        subtitle: Text('Admin'),
      ),
    );
  }
}
