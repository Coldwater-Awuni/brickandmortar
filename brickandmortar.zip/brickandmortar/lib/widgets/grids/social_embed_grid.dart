import 'package:flutter/material.dart';
import '../../pages/homepage/social_media_embed/social_embed.dart';


class SocialMediaEmbedGrid extends StatelessWidget {
  final List<String> urls;
  final double containerWidth;
  final double containerHeight;

  const SocialMediaEmbedGrid({
    Key? key,
    required this.urls,
    this.containerWidth = 300,
    this.containerHeight = 400,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenWidth = constraints.maxWidth;
        final spacing = 16.0;
        final availableWidth = screenWidth - (2 * spacing);
        final itemWidth = (availableWidth / 3).floor().toDouble();

        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              for (var url in urls)
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: spacing / 2),
                  child: SocialMediaEmbedContainer(
                    embedUrl: url,
                    width: itemWidth,
                    height: containerHeight,
                  ),
              ),
            ],
          ),
        );
      },
    );
  }
  
}
