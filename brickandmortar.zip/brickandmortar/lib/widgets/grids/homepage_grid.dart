import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class bundlegrids extends StatelessWidget {
  final List<Map<String, String>> bundles;
  final int crossAxisCount;
  const bundlegrids({
    
  
  required this.bundles, 
  required this.crossAxisCount}
  
  );

  @override
  Widget build(BuildContext context) {
    return  GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: 16,
        mainAxisSpacing: 24,
        childAspectRatio: 1.0, // Adjust the aspect ratio to your needs
      ),
      itemCount: bundles.length,
      itemBuilder: (context, index) {
        return _buildGridItem(context, bundles[index]);
      },
    );

    
  }
 Widget _buildGridItem( BuildContext context, Map<String, String> bundle) {
    return MouseRegion(
      cursor:
          SystemMouseCursors.click, // Change mouse cursor to pointing finger
      child: GestureDetector(
        onTap: () {
          // Navigate to a new page with the provided route URL when the item is tapped
          // Navigator.pushNamed(context, bundle['route']!);
          context.goNamed(bundle['route']!);
        },
        child: Column(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(bundle["image"]!),
                    fit: BoxFit.cover,
                  ),
                 
                ),
              ),
            ),
            SizedBox(height: 8),
            GestureDetector(
              onTap: () {
                // Navigate to a new page with the provided route URL when the title is tapped
                // Navigator.pushNamed(context, bundle['route']!);
                 context.goNamed(bundle['route']!);
              },
              child: Text(
                bundle["title"]!,
                style: const TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }

  
}
