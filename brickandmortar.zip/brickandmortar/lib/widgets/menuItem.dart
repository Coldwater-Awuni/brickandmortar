// import 'package:brickandmortar/constants/nav_items.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:popover/popover.dart';

// class nav extends StatelessWidget {
//   const nav({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: () => {
//         showPopover(context: context,
//          bodyBuilder: ,
//          width: 200,
//          height: 150,
         
//          )
//       },
//       child:Text(
//         "New",
//         style: TextStyle(
//           color: Colors.black26
//         ),
//       ) ,
//     );
//   }
// }

