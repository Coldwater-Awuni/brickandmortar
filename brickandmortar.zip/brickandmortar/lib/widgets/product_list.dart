// // TODO Implement this library.import 'package:flutter/material.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import '../providers/dashboard_provider.dart';

// class ProductList extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     final products = Provider.of<DashboardProvider>(context).products;

//     return ListView.builder(
//       itemCount: products.length,
//       itemBuilder: (ctx, i) => ListTile(
//         leading: Image.asset(products[i].imageUrl),
//         title: Text(products[i].name),
//         subtitle: Text('\$${products[i].price}'),
//       ),
//     );
//   }
// }
