import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:brickandmortar/routes/routes.dart'; // Import the routes
import 'package:brickandmortar/utils/responsive.dart';

// Footer Column widget that displays a title and a list of clickable items
class FooterColumn extends StatelessWidget {
  final String title; // Title of the column
  final List<String> items; // List of items in the column
  final List<String> routes; // Corresponding routes for the items

  const FooterColumn({
    required this.title,
    required this.items,
    required this.routes,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Column title
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          // Iterate through items and create a clickable text widget for each
          for (int i = 0; i < items.length; i++)
            MouseRegion(
              cursor: SystemMouseCursors.click,
              // On hover enter and exit handlers
              onEnter: (event) => _onHover(context, true, title + items[i]),
              onExit: (event) => _onHover(context, false, title + items[i]),
              child: GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, routes[i]);
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5.0),
                  // Animate text style on hover
                  child: AnimatedDefaultTextStyle(
                    style: TextStyle(
                      color: _isHovered(context, title + items[i]) ? Colors.redAccent : Colors.white,
                      fontSize: 14,
                      decoration: TextDecoration.underline,
                    ),
                    duration: const Duration(milliseconds: 200),
                    child: Text(items[i]),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // Check if the specific item is hovered
  bool _isHovered(BuildContext context, String key) {
    final hoverMap = context.dependOnInheritedWidgetOfExactType<HoverInheritedWidget>()?.hoverMap ?? {};
    return hoverMap[key] ?? false;
  }

  // Update hover state for the specific item
  void _onHover(BuildContext context, bool hovering, String key) {
    final hoverNotifier = context.dependOnInheritedWidgetOfExactType<HoverInheritedWidget>()?.hoverNotifier;
    hoverNotifier?.value = {
      ...hoverNotifier.value,
      key: hovering,
    };
  }
}

// Inherited Widget to manage hover state across the footer
class HoverInheritedWidget extends InheritedNotifier<ValueNotifier<Map<String, bool>>> {
  final ValueNotifier<Map<String, bool>> hoverNotifier;

  const HoverInheritedWidget({
    required Widget child,
    required this.hoverNotifier,
  }) : super(notifier: hoverNotifier, child: child);

  // Get the current hover state map
  Map<String, bool> get hoverMap => hoverNotifier.value;

  @override
  bool updateShouldNotify(HoverInheritedWidget oldWidget) {
    return hoverNotifier != oldWidget.hoverNotifier;
  }
}

// Large Screen Footer Layout
Widget largeScreenFooter(BuildContext context) {
  return Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      const FooterColumn(
        title: 'HELP',
        items: ['Help Center', 'Shipping', 'Returns', 'Product Recalls', 'Contact Us'],
        routes: ['/help-center', '/shipping', '/returns', '/product-recalls', '/contact-us'],
      ),
      const FooterColumn(
        title: 'EXPLORE',
        items: ['Design Resources', 'Blog', 'Gift Cards', 'Financing', 'About Us', 'Reviews', 'Press', 'Careers'],
        routes: ['/design-resources', '/blog', '/gift-cards', '/financing', '/about-us', '/reviews', '/press', '/careers'],
      ),
      const FooterColumn(
        title: 'ACCOUNT',
        items: ['Login/Register', 'My Favorites'],
        routes: ['/login', '/favorites'],
      ),
      const FooterColumn(
        title: 'B2B',
        items: ['Business', 'Trade'],
        routes: ['/business', '/trade'],
      ),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            const Text(
              'Get new products and promotions in your inbox.',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Your email',
                      hintStyle: const TextStyle(color: Colors.grey),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30.0),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    // Handle subscribe action
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 30.0),
                  ),
                  child: const Text(
                    'SUBSCRIBE',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ],
  );
}

// Small Screen Footer Layout
Widget smallScreenFooter(BuildContext context) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const FooterColumn(
        title: 'HELP',
        items: ['Help Center', 'Shipping', 'Returns', 'Product Recalls', 'Contact Us'],
        routes: ['/help-center', '/shipping', '/returns', '/product-recalls', '/contact-us'],
      ),
      const SizedBox(height: 20),
      const FooterColumn(
        title: 'EXPLORE',
        items: ['Design Resources', 'Blog', 'Gift Cards', 'Financing', 'About Us', 'Reviews', 'Press', 'Careers'],
        routes: ['/design-resources', '/blog', '/gift-cards', '/financing', '/about-us', '/reviews', '/press', '/careers'],
      ),
      const SizedBox(height: 20),
      const FooterColumn(
        title: 'ACCOUNT',
        items: ['Login/Register', 'My Favorites'],
        routes: ['/login', '/favorites'],
      ),
      const SizedBox(height: 20),
      const FooterColumn(
        title: 'B2B',
        items: ['Business', 'Trade'],
        routes: ['/business', '/trade'],
      ),
      const SizedBox(height: 20),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Get new products and promotions in your inbox.',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Your email',
                    hintStyle: const TextStyle(color: Colors.grey),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30.0),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: () {
                  // Handle subscribe action
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 30.0),
                ),
                child: const Text(
                  'SUBSCRIBE',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ],
      ),
    ],
  );
}

// Footer Section widget that includes multiple FooterColumns and other footer content
Widget footerSection(BuildContext context) {
  return HoverInheritedWidget(
    hoverNotifier: ValueNotifier<Map<String, bool>>({}),
    child: Container(
      color: const Color(0xFF4A4A4A), // Grey background color
      padding: const EdgeInsets.symmetric(vertical: 40.0, horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Social Media Icons Row
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const FaIcon(FontAwesomeIcons.facebook, color: Colors.white),
                onPressed: () {},
              ),
              IconButton(
                icon: const FaIcon(FontAwesomeIcons.pinterest, color: Colors.white),
                onPressed: () {},
              ),
              IconButton(
                icon: const FaIcon(FontAwesomeIcons.instagram, color: Colors.white),
                onPressed: () {},
              ),
              IconButton(
                icon: const FaIcon(FontAwesomeIcons.twitter, color: Colors.white),
                onPressed: () {},
              ),
              IconButton(
                icon: const FaIcon(FontAwesomeIcons.tiktok, color: Colors.white),
                onPressed: () {},
              ),
            ],
          ),
          const SizedBox(height: 20),
          // Use ResponsiveWidget to switch between different screen layouts
          ResponsiveWidget(
            largeScreen: largeScreenFooter(context),
            smallScreen: smallScreenFooter(context),
          ),
          const SizedBox(height: 20),
          // Legal Information Section
          const Text(
            'Terms of Use - Privacy Policy - Do Not Sell My Personal Information - Cookie Settings - Accessibility - Shop',
            style: TextStyle(
              color: Colors.white,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'Copyright © 2024 Article.com. All rights reserved.',
            style: TextStyle(
              color: Colors.white,
              fontSize: 12,
            ),
          ),
        ],
      ),
    ),
  );
}
