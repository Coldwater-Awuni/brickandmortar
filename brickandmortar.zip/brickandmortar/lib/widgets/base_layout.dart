// import 'package:brickandmortar/widgets/newNavbar.dart';
// import 'package:brickandmortar/widgets/sideNivigationBar.dart';
// import 'package:flutter/material.dart';

// class BaseLayout extends StatelessWidget {
//   final Widget body;
//   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

//   BaseLayout({required this.body});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       key: _scaffoldKey,
//       appBar: Navbarnew(), // Use the NavbarNew widget
//       drawer: NavDrawer(),
//       body: body,
//     );
//   }
// }
