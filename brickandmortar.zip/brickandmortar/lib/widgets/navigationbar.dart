import 'package:brickandmortar/constants/nav_items.dart';
import 'package:brickandmortar/constants/submenudata.dart';
import 'package:brickandmortar/providers/cart_provider.dart';
import 'package:brickandmortar/widgets/menus.dart';

import 'package:flutter/material.dart';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:brickandmortar/routes/gorouting.dart';
import 'package:provider/provider.dart';


class Navbar extends StatefulWidget {
  @override
  _NavigationBarState createState() => _NavigationBarState();
}

class _NavigationBarState extends State<Navbar> {
 final GlobalKey _navBarKey = GlobalKey();
  final LayerLink _layerLink = LayerLink();



  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: Container(
        key: _navBarKey,
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                _buildLogo(),
                SizedBox(width: 20),
                Expanded(
                  child: _buildSearchBar(),
                ),
                SizedBox(width: 20),
                _buildIconButtons(),
              ],
            ),
            SizedBox(height: 10),
             CustomMenuBar(subMenuData: subMenuData),
          ],
        ),
      ),
    );
  }





    Widget _buildLogo() {
    return SizedBox(
      height: 50,
      width: 100,
      child: Image.asset('assets/logo.png'),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(20),
      ),
      child:  Row(
        children: <Widget>[
          Icon(Icons.search),
          SizedBox(width: 10),
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search...',
                border: InputBorder.none,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIconButtons() {
    return Row(
      children: <Widget>[
        IconButton(
          icon: Icon(Icons.account_circle),
          onPressed: () {
            // Add functionality for account icon
          },
        ),
        SizedBox(width: 10),
        IconButton(
          icon: Icon(Icons.favorite),
          onPressed: () {
            // Add functionality for favorite icon
           context.goNamed('favorite');
          },
        ),
        SizedBox(width: 10),
         Stack(
            children: [
              IconButton(
                icon: Icon(Icons.shopping_cart),
                onPressed: () {
                context.go('/cartpage');
                },
              ),
              Positioned(
                right: 0,
                child: Consumer<CartProvider>(
                  builder: (context, cartProvider, child) {
                    return cartProvider.getItemCount() > 0
                        ? Container(
                            padding: EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              color: Colors.red,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            constraints: BoxConstraints(
                              minWidth: 16,
                              minHeight: 16,
                            ),
                            child: Text(
                              '${cartProvider.getItemCount()}',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          )
                        : Container();
                  },
                ),
              ),
              ],
        ),
      ],
    );
  }

}

 

 
 
 
  Widget _buildSocialIcons() {
    return Row(
      children: <Widget>[
        IconButton(
          icon: FaIcon(FontAwesomeIcons.facebook, size: 18),
          onPressed: () {
            // Add functionality for Facebook icon
          },
        ),
        IconButton(
          icon: FaIcon(FontAwesomeIcons.xTwitter, size: 18),
          onPressed: () {
            // Add functionality for Twitter icon
          },
        ),
        IconButton(
          icon: FaIcon(FontAwesomeIcons.instagram, size: 18),
          onPressed: () {
            // Add functionality for Instagram icon
          },
        ),
        IconButton(
          icon: FaIcon(FontAwesomeIcons.whatsapp, size: 18),
          onPressed: () {
            // Add functionality for WhatsApp icon
          },
        ),
      ],
    );
  }

