import 'package:brickandmortar/constants/submenudata.dart';
import 'package:flutter/material.dart';

class NavDrawer extends StatefulWidget {
  @override
  _NavDrawerState createState() => _NavDrawerState();
}

class _NavDrawerState extends State<NavDrawer> {


  Map<String, bool> _expandedState = {};

  @override
  void initState() {
    super.initState();
    for (var key in subMenuData.keys) {
      _expandedState[key] = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
              color: Color.fromARGB(255, 136, 175, 207),
            ),
            child: Text(
              'Menu',
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
          ),
          ...subMenuData.entries.map((entry) {
            if (entry.value is Map<String, String>) {
              return _buildSingleItem(entry.key, entry.value['route']);
            } else if (entry.value is List) {
              return _buildExpandableItem(entry.key, entry.value);
            }
            return SizedBox.shrink();
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildSingleItem(String title, String route) {
    return ListTile(
      leading: Icon(_getIconForTitle(title)),
      title: Text(title),
      onTap: () {
        Navigator.pop(context);
        Navigator.pushNamed(context, route);
      },
    );
  }

  Widget _buildExpandableItem(String title, List<Map<String, String>> items) {
    return ExpansionTile(
      leading: Icon(_getIconForTitle(title)),
      title: Text(title),
      children: items.map((item) {
        return ListTile(
          title: Text(item['title']!),
          onTap: () {
            Navigator.pop(context);
            Navigator.pushNamed(context, item['route']!);
          },
        );
      }).toList(),
      onExpansionChanged: (expanded) {
        setState(() {
          _expandedState[title] = expanded;
        });
      },
    );
  }

  IconData _getIconForTitle(String title) {
    switch (title) {
      case 'Home':
        return Icons.home;
      case 'Products':
        return Icons.category;
      case 'Rooms':
        return Icons.room;
      case 'Outdoor':
        return Icons.outdoor_grill;
      case 'About':
        return Icons.info;
      default:
        return Icons.menu;
    }
  }
}