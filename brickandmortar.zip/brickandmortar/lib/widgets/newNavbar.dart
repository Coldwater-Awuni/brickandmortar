import 'package:brickandmortar/constants/contants.dart';
import 'package:brickandmortar/utils/responsive.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:brickandmortar/constants/nav_items.dart';
import 'package:brickandmortar/constants/submenudata.dart';
import 'package:brickandmortar/providers/cart_provider.dart';
import 'package:brickandmortar/widgets/menus.dart';

class Navbarnew extends StatelessWidget  {
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 600) {
          return DesktopNavbar();
        } else {
          return MobileNavbar();
        }
      },
    );
  }
  
  
  
}

class DesktopNavbar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              _buildLogo(),
              SizedBox(width: 20),
              Expanded(
                child: _buildSearchBar(),
              ),
              SizedBox(width: 20),
              _buildIconButtons(context),
            ],
          ),
          SizedBox(height: 10),
          CustomMenuBar(subMenuData: subMenuData),
        ],
      ),
    );
  }
}

class MobileNavbar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: _buildLogo(),
      actions: [
        IconButton(
          icon: Icon(Icons.search),
          onPressed: () {
            // Implement search functionality for mobile
            showSearch(context: context, delegate: CustomSearchDelegate());
          },
        ),
        _buildCartIcon(context),
      ],
      leading: IconButton(
        icon: Icon(Icons.menu),
        onPressed: () {
          Scaffold.of(context).openDrawer();
        },
      ),
    );
  }
}

class CustomSearchDelegate extends SearchDelegate {
  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    // Implement search results
    return Container();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    // Implement search suggestions
    return Container();
  }
}

Widget _buildLogo() {
  return SizedBox(
    height: 50,
    width: 100,
    child: Image.asset(Logo),
  );
}

Widget _buildSearchBar() {
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 10),
    decoration: BoxDecoration(
      color: Colors.grey[200],
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      children: <Widget>[
        Icon(Icons.search),
        SizedBox(width: 10),
        Expanded(
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Search...',
              border: InputBorder.none,
            ),
          ),
        ),
      ],
    ),
  );
}

Widget _buildIconButtons(BuildContext context) {
  return Row(
    children: <Widget>[
      IconButton(
        icon: Icon(Icons.account_circle),
        onPressed: () {
          // Add functionality for account icon
        },
      ),
      SizedBox(width: 10),
      IconButton(
        icon: Icon(Icons.favorite),
        onPressed: () {
         context.goNamed('favorite');
        },
      ),
      SizedBox(width: 10),
      _buildCartIcon(context),
    ],
  );
}


Widget _buildCartIcon(BuildContext context) {
  return Stack(
    children: [
      IconButton(
        icon: Icon(Icons.shopping_cart),
        onPressed: () => _handleCartIconPress(context),
      ),
      Positioned(
        right: 0,
        child: Consumer<CartProvider>(
          builder: (context, cartProvider, child) {
            return _buildCartBadge(cartProvider);
          },
        ),
      ),
    ],
  );
}

void _handleCartIconPress(BuildContext context) {
  if (ResponsiveWidget.isSmallScreen(context)) {
    context.goNamed('cartpage');
  } else if (ResponsiveWidget.isLargeScreen(context) || 
            (ResponsiveWidget.isMediumScreen(context) && Scaffold.of(context).hasEndDrawer)) {
    Scaffold.of(context).openEndDrawer();
  }
}

Widget _buildCartBadge(CartProvider cartProvider) {
  final itemCount = cartProvider.getItemCount();
  return itemCount > 0
      ? Container(
          padding: EdgeInsets.all(2),
          decoration: BoxDecoration(
            color: Colors.red,
            borderRadius: BorderRadius.circular(10),
          ),
          constraints: BoxConstraints(
            minWidth: 16,
            minHeight: 16,
          ),
          child: Text(
            '$itemCount',
            style: TextStyle(
              color: Colors.white,
              fontSize: 10,
            ),
            textAlign: TextAlign.center,
          ),
        )
      : Container();
}