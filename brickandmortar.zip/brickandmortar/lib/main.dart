
import 'package:brickandmortar/providers/cart_provider.dart';
import 'package:brickandmortar/routes/gorouting.dart';
import 'package:flutter/foundation.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (kIsWeb) {
     await Firebase.initializeApp(options: const FirebaseOptions(
  apiKey: "AIzaSyDbqxKWOmegnCzN1wWKhYdcHaOu7WPdPUM",
  authDomain: "brick-and-mortar-1ccb7.firebaseapp.com",
  projectId: "brick-and-mortar-1ccb7",
  storageBucket: "brick-and-mortar-1ccb7.appspot.com",
  messagingSenderId: "458516363949",
  appId: "1:458516363949:web:b2ffccd99ddd3f525f2424",
  measurementId: "G-1BL8WZF1GF"

    
    )); // Initialize Firebase
  }
  else{
    Firebase.initializeApp();
  }
 
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  
  
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    
    return ChangeNotifierProvider(
      create: (context) => CartProvider(),
      child: MaterialApp.router(
         title: 'Brick and mortar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(       
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      routerConfig: router,
      ),
     
    );
  }
}
