package com.example.brickandmortar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
